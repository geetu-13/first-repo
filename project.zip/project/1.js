//document.body.style.backgroundColor=#e6f2ff;
setInterval(
function()
{

/*var randomColor=Math.floor(Math.random()*16777215).toString(16);*/
var randomColor=change();
document.body.style.backgroundColor="#"+randomColor;
}, 2000);

function change()
{
var x=Math.floor(Math.random()*(88-1+1))+1;
switch(x)
{
case 1: return "e6f2ff";
case 2: return "cce6ff";
case 3: return "b3d9ff";
case 4: return "99ccff";
case 5: return "80bfff";
case 6: return "e6ffff";
case 7: return "ccffff";
case 8: return "b3ffff";
case 9: return "ecf2f9";
case 10: return "d9e6f2";
case 11: return "c6d9f2";
case 12: return "b3cce6";
case 13: return "9fbfdf";
case 14: return "8cb3d9";
case 15: return "ebf0fa";
case 16: return "d6e0f5";
case 17: return "e6f9ff";
case 18: return "ccf2ff";
case 19: return "b3ecff";
case 20: return "f0f5f5";
case 21: return "e0ebeb";
case 22: return "d1e0e0";
case 23: return "c2d6d6";
case 24: return "b3cccc";
case 25: return "d6f5f5";
case 26: return "c2f0f0";
case 27: return "ecf9f2";
case 28: return "d9f2e6";
case 29: return "c6ecd9";
case 30: return "b3e6cc";
case 31: return "9fdfbf";
case 32: return "8cd9b3";
case 33: return "79d2a6";
case 34: return "e6fff9";
case 35: return "ccfff2";
case 36: return "b3ffec";
case 37: return "99ffe6";
case 38: return "80ffdf";
case 39: return "66ffd9";
case 40: return "4dffd2";
case 41: return "33ffcc";
case 43: return "1affc6";
case 42: return "00ffbf";
case 44: return "e6e6ff";
case 45: return "ccccff";
case 46: return "b3b3ff";
case 47: return "e6f2ff";
case 48: return "cce6ff";
case 49: return "e6e6ff";
case 50: return "ccccff";
case 51: return "e6ffe6";
case 52: return "ccffcc"
case 53: return "f7e6ff";
case 54: return "eeccff";
case 55: return "e6b3ff";
case 56: return "f2f2f2";
case 57: return "e6e6e6";
case 58: return "d9d9d9";
case 59: return "ffe6ff";
case 60: return "ffccff";
case 61: return "e6ffcc";
case 62: return "e6ffcc";
case 63: return "d9ffb3";
case 64: return "ffffe6";
case 65: return "ffffcc";
case 66: return "ffffb3";
case 67: return "ffe6e6";
case 68: return "ffcccc";
case 69: return "ffb3b3";
case 70: return "fff2e6";
case 71: return "ffd9b3";
case 72: return "ffcc99";
case 73: return "ffbf80";
case 74: return "ffe6ee";
case 75: return "ffb3cc";
case 76: return "ffccdd";
case 77: return "ffddcc";
case 78: return "ffccb3";
case 79: return "ffbb99";
case 80: return "f2d9e6";
case 81: return "ecc9e6";
case 82: return "ecc6d9";
case 83: return "fff5e6";
case 84: return "ffebcc";
case 85: return "ffe0b3";
case 86: return "ffd699";
case 87: return "ffcc80";
case 88: return "ffc266";
}
}
