function f1(x)
{x.style.height="45px";
x.style.width="45px";
}
function f2(x)
{x.style.height="30px";
x.style.width="30px";
}